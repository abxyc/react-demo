import expect from 'expect';

describe('Our first test', ()=>{
  it('should  pass', function () {
    expect(true).toEqual(true);
  });

});
